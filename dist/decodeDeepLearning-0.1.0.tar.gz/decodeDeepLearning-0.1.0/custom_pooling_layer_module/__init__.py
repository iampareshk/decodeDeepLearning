__version__ = '0.1.0'

# custom_pooling_layer_module/__init__.py
from .custom_pooling_layer import CustomLayer

